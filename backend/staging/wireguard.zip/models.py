"""
WireGuard Module - Database Models

SQLModel tables for WireGuard instances, clients, groups, and rules.
"""
from typing import Optional, List, Dict
from datetime import datetime
from sqlmodel import Field, SQLModel, Relationship, JSON, Column
import uuid


class WgInstance(SQLModel, table=True):
    """WireGuard VPN server instance."""
    __tablename__ = "wg_instance"
    
    id: str = Field(primary_key=True)
    name: str = Field(max_length=100)
    port: int = Field(unique=True)
    subnet: str = Field(max_length=50)
    interface: str = Field(unique=True, max_length=20)
    
    private_key: str
    public_key: str
    
    tunnel_mode: str = Field(default="full")
    routes: List[Dict] = Field(default=[], sa_column=Column(JSON))
    dns_servers: List[str] = Field(default=["8.8.8.8", "1.1.1.1"], sa_column=Column(JSON))
    firewall_default_policy: str = Field(default="ACCEPT")
    status: str = Field(default="stopped")
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    clients: List["WgClient"] = Relationship(
        back_populates="instance",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"}
    )
    groups: List["WgGroup"] = Relationship(
        back_populates="instance",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"}
    )


class WgClient(SQLModel, table=True):
    """WireGuard VPN client peer."""
    __tablename__ = "wg_client"
    
    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    instance_id: str = Field(foreign_key="wg_instance.id", index=True)
    name: str = Field(max_length=100)
    
    private_key: str
    public_key: str
    preshared_key: str
    allocated_ip: str = Field(max_length=50)
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_handshake: Optional[datetime] = None
    
    instance: "WgInstance" = Relationship(back_populates="clients")
    group_links: List["WgGroupMember"] = Relationship(
        back_populates="client",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"}
    )


class WgGroup(SQLModel, table=True):
    """Firewall group for WireGuard clients."""
    __tablename__ = "wg_group"
    
    id: str = Field(primary_key=True)
    instance_id: str = Field(foreign_key="wg_instance.id", index=True)
    name: str = Field(max_length=100)
    description: str = Field(default="", max_length=500)
    
    instance: "WgInstance" = Relationship(back_populates="groups")
    client_links: List["WgGroupMember"] = Relationship(
        back_populates="group",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"}
    )
    rules: List["WgGroupRule"] = Relationship(
        back_populates="group",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"}
    )


class WgGroupMember(SQLModel, table=True):
    """Junction table for groups and clients."""
    __tablename__ = "wg_group_member"
    
    group_id: str = Field(foreign_key="wg_group.id", primary_key=True)
    client_id: uuid.UUID = Field(foreign_key="wg_client.id", primary_key=True)
    
    group: "WgGroup" = Relationship(back_populates="client_links")
    client: "WgClient" = Relationship(back_populates="group_links")


class WgGroupRule(SQLModel, table=True):
    """Firewall rule for a group."""
    __tablename__ = "wg_group_rule"
    
    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    group_id: str = Field(foreign_key="wg_group.id", index=True)
    
    action: str
    protocol: str
    port: Optional[str] = None
    destination: str
    description: str = Field(default="", max_length=255)
    order: int = Field(default=0)
    
    group: "WgGroup" = Relationship(back_populates="rules")


class WgMagicToken(SQLModel, table=True):
    """Temporary token for client config sharing."""
    __tablename__ = "wg_magic_token"
    
    token: str = Field(primary_key=True)
    client_id: uuid.UUID = Field(foreign_key="wg_client.id", index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime
    used: bool = Field(default=False)


# --- Pydantic Schemas ---

class WgInstanceCreate(SQLModel):
    name: str
    port: int
    subnet: str
    tunnel_mode: str = "full"
    routes: List[Dict] = []
    dns_servers: List[str] = ["8.8.8.8", "1.1.1.1"]


class WgInstanceRead(SQLModel):
    id: str
    name: str
    port: int
    subnet: str
    interface: str
    public_key: str
    tunnel_mode: str
    routes: List[Dict]
    dns_servers: List[str]
    firewall_default_policy: str
    status: str
    client_count: int = 0


class WgClientCreate(SQLModel):
    name: str


class WgClientRead(SQLModel):
    id: uuid.UUID
    name: str
    allocated_ip: str
    public_key: str
    created_at: datetime
    last_handshake: Optional[datetime]
